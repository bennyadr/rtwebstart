<?php
return array (
	'Email' => 'Email',
	'Nickname' => 'Benutzername',
	'Password' => 'Kennwort',
	'Sorry, but password is incorrect' => 'Verzeihung, aber das Kennwort ist falsch',
	'Submit' => 'Senden',
	'This {attribute} is taken by another user. If this is your account, enter password in field below or change {attribute} and leave password blank.' => '{attribute} ist durch einen anderen Benutzer eingenommen. Falls es ist Ihres Konto, eingeben Sie bitte das Kennwort oder ändern Sie {attribute}.',
	'Please specify your nickname and email to end with registration.' => 'Bitte geben Sie Ihre E-Mail und Benutzername ein, um mit der Registrierung zu beenden.',
	'Please specify your nickname to end with registration.' => 'Bitte geben Sie Ihre E-Mail ein, um mit der Registrierung zu beenden.',
	'Please specify your email to end with registration.' => 'Bitte geben Sie Ihre Benutzername ein, um mit der Registrierung zu beenden.',
	'If you remove this social network account, you will you will not be able to login with it.\\n\\nDo you realy want to remove this account?' => 'Falls Sie entfernen dieses Konto, wird es unmöglich mit dieses Konto einlogen.\\n\\nWollen Sie fortsetzen?',
	'Remove' => 'Entfernen',
	
	'Sorry, but your account' => 'Verzeihung, aber Ihr Konto',
	'must be activated! Check your email for details!' => 'noch nicht Aktiviert! Überprüfen Sie Ihre E-Mail für Details!',
	'is banned!' => 'wurde gesperrt!',
	'Return to main page' => 'Zurück zur Hauptseite',
	'Return to login page' => 'Zurück zur Login-Seite',
);
