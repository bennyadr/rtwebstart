<?php
return array (
	'Email' => 'Email',
	'Nickname' => 'Имя пользователя',
	'Password' => 'Пароль',
	'Sorry, but password is incorrect' => 'Извините, но пароль не верный',
	'Submit' => 'Отправить',
	'This {attribute} is taken by another user. If this is your account, enter password in field below or change {attribute} and leave password blank.' => 'Этот {attribute} занят другим пользователем. Если это ваш аккаунт, введите пароль в поле ниже или измените поле {attribute}, а пароль оставьте пустым.',
	'Please specify your nickname and email to end with registration.' => 'Пожалуйста, укажите имя пользователя и email, что бы завершить регистрацию.',
	'Please specify your nickname to end with registration.' => 'Пожалуйста, укажите имя пользователя, что бы завершить регистрацию.',
	'Please specify your email to end with registration.' => 'Пожалуйста, укажите ваше имя email, что бы завершить регистрацию.',
	'If you remove this social network account, you will you will not be able to login with it.\\n\\nDo you realy want to remove this account?' => 'Если вы удалите этот аккаунт, вы не сможете зайти с помощью него на сайт.\\n\\nВы действительно хотите удалить этот аккаунт?',
	'Remove' => 'Удалить',
	
	
	'Sorry, but your account' => 'Извините, но ваш аккаунт',
	'must be activated! Check your email for details!' => 'не активирован! На ваш почтовый ящик было выслано письмо с дополнительной информацией!',
	'is banned!' => 'заблокирован!',
	'Return to main page' => 'Вернуться на главную страницу',
	'Return to login page' => 'Вернуться на страницу входа',

  'Sign in with' => 'Войти через',
  'Connect with' => 'Подключить ',
);
